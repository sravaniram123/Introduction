
## ~~What is DevOps???~~ Why DevOps? : 

Automate the process, reduce the manual activities.

DevOps = Devlopment Operations

### Activities in Devlopment: 

	Analysis/planning/requirement
	Code management
	Build 
	Deploy (in lower env)
	test
	release
	
	Supporting Tools: JIRA/Confluence, Git, Maven etc (other similar tools)
	
### Activities in Operations: 
	
	Environment setup
	Deploy (in higher env)
	Testing in various higher env - system test, performance test, load test, auto scaling etc
	Monitoring
	
	Supporting Tools: AWS, Ansible, Docker, splunk, nagios etc (other similar tools)
	
### DevOps for???

	DevOps for JAVA (Platform: Windows/Linux)
	DevOps for .net/C# (Platform: Windows)
	DevOps for PHP. (Platform: Linux)
	DevOps for Python. (Platform: Linux)
	DevOps for Mainframes. (Platform: Linux) : https://compuware.com/10-cross-platform-mainframe-devops-tools/
	DevOps for Salesforce. (Platform: Salesforce cloud)
	
	etc	

