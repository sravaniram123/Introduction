
Build & Release - SCM - DevOps Engineer Activies with Phase-1: Jenkins, Git, Maven, Nexus, Tomcat.

1. DevOps Intro.

2. Maven intro & main features.

3. GitHub intro & main features.

4. Jenkins intro & main features.

5. Nexus Intro & main features.

6. Tomcat Intro & main features.

7. Linux Intro & important commands.

8. Phase-1.1

9. Phase-1.2

10. Phase-1.3

11. Responsibilities of DevOps team with the tool Maven.

12. Responsibilities of DevOps team with the tool GitHub.

13. Responsibilities of DevOps team with the tool Jenkins.

14. Responsibilities of DevOps team with the tool Nexus.

15. Responsibilities of DevOps team with the tool Tomcat.

16. Phase-1-Examples. (CI/CD piepline with BlueOcean plugin, Maven release, Jenkins pipeline script for CI/CD etc)
